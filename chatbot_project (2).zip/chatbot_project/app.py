from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from datetime import timedelta
from werkzeug.utils import secure_filename
import os

UPLOAD_FOLDER = 'uploads'

app = Flask(__name__)  # 🔴 Yeh pehle hona chahiye
app.secret_key = "secretkey"
app.permanent_session_lifetime = timedelta(days=7)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER  # ✅ Ab yeh theek hai

# 📁 Folder create if not exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Dummy user database
users = {"admin": "1234"}

@app.route('/chat')
def home():
    if 'user' in session:
        return render_template('index.html')
    return redirect(url_for('login_page'))

@app.route('/')
def root_redirect():
    return redirect(url_for('start_page'))

@app.route('/start')
def start_page():
    return render_template('welcome.html')

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['user'] = username
            session.permanent = 'remember' in request.form
            return redirect(url_for('home'))
        return render_template('login.html', error="Invalid credentials")
    return render_template('login.html')

@app.route('/signup', methods=['POST'])
def signup():
    username = request.form['username']
    password = request.form['password']
    if username not in users:
        users[username] = password
        session['user'] = username
        session.permanent = True
        return redirect(url_for('home'))
    return render_template('login.html', error="User already exists")

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login_page'))

@app.route('/get', methods=['POST'])
def chatbot_response():
    msg = request.form.get('msg')
    file = request.files.get('file')

    if file:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        reply = f"📁 Received your file: {filename}"
    elif msg:
        reply = generate_reply(msg)
    else:
        reply = "No message or file received."

    return jsonify({'reply': reply})

@app.route('/history')
def get_history():
    return jsonify(session.get('history', []))

@app.route('/new_chat')
def new_chat():
    session['history'] = []
    return '', 204

def generate_reply(msg):
    msg = msg.lower().strip()
    if "hi" in msg or "hello" in msg:
        return "Hello! How can I assist you today?"
    elif "joke" in msg:
        return "Why did the developer go broke? Because he used up all his cache. 😄"
    else:
        return "I'm not sure, can you rephrase?"

if __name__ == '__main__':
    app.run(debug=True)
